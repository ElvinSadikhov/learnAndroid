//package puzzle8;

import java.util.ArrayList;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

public class Solver {

	private Move lastMove;

	private class Move implements Comparable<Move> {

		private Move prevMove;
		private Board board;
		private int moves = 0;
		private int manhattan;

		public Move(Board board) {
			this.board = board;
			this.manhattan = board.manhattan();
		}

		public Move(Board board, Move prevMove) {
			this(board);
			this.prevMove = prevMove;
			this.moves = prevMove.moves + 1;
		}

		@Override
		public int compareTo(Move move) {
			return (this.manhattan - move.manhattan) + (this.moves - move.moves);
		}

	}

	// find a solution to the initial board (using the A* algorithm)
	public Solver(Board initial) {
		if (initial == null)
			throw new IllegalArgumentException();
		MinPQ<Move> mainPQ = new MinPQ<>();
		mainPQ.insert(new Move(initial));
		MinPQ<Move> twinPQ = new MinPQ<>();
		twinPQ.insert(new Move(initial.twin()));

		while (true) {
			lastMove = nextMove(mainPQ);
			if (lastMove != null || nextMove(twinPQ) != null)
				return;
		}
	}

	private Move nextMove(MinPQ<Move> moves) {
		if (moves.isEmpty())
			return null;

		Move bestMove = moves.delMin();

		if (bestMove.board.isGoal())
			return bestMove;

		for (Board neighbor : bestMove.board.neighbors()) {
			if (bestMove.prevMove == null || !neighbor.equals(bestMove.prevMove.board)) {
				moves.insert(new Move(neighbor, bestMove));
			}
		}

		return null;
	}

	// is the initial board solvable? (see below)
	public boolean isSolvable() {
		return lastMove != null;
	}

	// min number of moves to solve initial board; -1 if unsolvable
	public int moves() {
		return isSolvable() ? lastMove.moves : -1;
	}

	// sequence of boards in a shortest solution; null if unsolvable
	public Iterable<Board> solution() {
		if (!isSolvable())
			return null;

		ArrayList<Board> reversedOrder = new ArrayList<>();
		Move temp = lastMove;
		while (temp != null) {
			reversedOrder.add(temp.board);
			temp = temp.prevMove;
		}

		ArrayList<Board> moves = new ArrayList<>();
		for (int i = reversedOrder.size() - 1; i >= 0; i--) {
			moves.add(reversedOrder.get(i));
		}
		return moves;
	}

	// test client (see below)
	public static void main(String[] args) {

		// create initial board from file
		In in = new In(args[0]);
		int n = in.readInt();
		int[][] tiles = new int[n][n];
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				tiles[i][j] = in.readInt();
		Board initial = new Board(tiles);

		// solve the puzzle
		Solver solver = new Solver(initial);

		// print solution to standard output
		if (!solver.isSolvable())
			StdOut.println("No solution possible");
		else {
			StdOut.println("Minimum number of moves = " + solver.moves());
			for (Board board : solver.solution())
				StdOut.println(board);
		}
	}
}